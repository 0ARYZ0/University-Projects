import numpy as np
import random

a = random.random() * 20
b = random.random() * 20
c = random.random() * 20

A = np.array([
    [1, c**2, c],
    [-c, c, 1-c],
    [b-a, -a, a+1]
])

B = np.array([
    1+b*c,
    b,
    a-c
])

x = np.linalg.solve(A, B)

A2 = np.array([
    [1, c**2 ,c],
    [0, c**3 + c, c**2 - c + 1],
    # [0, -a - (b-a)*c**2, a+1 - (b-a)*c]
    [0, 0, a+1 - (b-a)*c + (a+(b-a)*c**2)/(c**3+c)*(c**2 - c + 1)]
])

B2 = np.array([
    1 + b*c,
    b + c + b*c**2,
    # a-c - (b-a)*(1+b*c)
    a-c - (b-a)*(1+b*c) + (a+(b-a)*c**2)/(c**3+c) * (b + c + b*c**2)
])

x2 = np.linalg.solve(A2, B2)
print('before gaussian elimination:\n', x, '\n')
print('after gaussian elimination:\n', x2, '\n')