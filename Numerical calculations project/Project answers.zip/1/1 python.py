eq1 = "0.3x + 9y - z + 3w - 2m = 17"
eq2 = "7x + z - 4w - m = 3"
eq3 = "6x + 2z + 2y + m + 8w = 1"
eq4 = "-1.2z + 17y + w - x = 15"
eq5 = "y + 2w + z - x = -7"
eqs = [eq1, eq2, eq3, eq4, eq5]
NumOfEqs = len(eqs)

matrix = [[0 for j in range(NumOfEqs)] for i in range(NumOfEqs)]
answers = [None for i in range(NumOfEqs)]
variables = []
ignor = [' ', '+']
for eq in eqs:
    i = 0
    num = ''
    while(eq[i] != '='):
        if(eq[i] in ignor):
            i += 1
            continue
        if((eq[i] >= '0' and eq[i] <= '9') or eq[i] == '.' or eq[i] == '-'):
            num += eq[i]
        elif eq[i] in variables:
            if(num == '-' or num == ''):
                num += '1'
            matrix[eqs.index(eq)][variables.index(eq[i])] = float(num)
            num = ''
        else:
            if(num == '-' or num == ''):
                num += '1'
            variables += eq[i]
            matrix[eqs.index(eq)][variables.index(eq[i])] = float(num)
            num = ''
        i += 1
    i += 1
    while(i == ' '):
        i += 1
    while(i < len(eq)):
        num += eq[i]
        i +=1
    answers[eqs.index(eq)] = float(num)

for i in range(NumOfEqs):
     for j in range(i + 1, NumOfEqs):
        if(matrix[j][i] == 0):
            continue
        temp = -1 * (matrix[j][i] / matrix[i][i]) 
        answers[j] = answers[i] * temp
        for k in range(i, NumOfEqs):
            if(k == i):
                matrix[j][k] = 0
            else:
                matrix[j][k] = matrix[i][k] * temp + matrix[j][k]

final_results = [0 for i in range(NumOfEqs)]
for i in range(NumOfEqs - 1, -1, -1):
    final_results[i] = answers[i]
    for j in range(NumOfEqs - 1, i, -1):
        final_results[i] -= matrix[i][j] * final_results[j]
    final_results[i] = final_results[i]/ matrix[i][i]

for i in range(NumOfEqs):
    print(variables[i] + " = " + str(final_results[i]))
