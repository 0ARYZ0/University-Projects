import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

h = 0.1

a, b = 0, 10
c, d = 0, 8

# linspace takes half-open intervals
y = np.arange(c, d + h, h)
x = np.arange(a, b + h, h)

n = x.size
m = y.size

z = np.empty((n, m), dtype=np.float32)

# boundary conditions
z[0] = y
z[-1] = 3 * y

z[:, 0] = 6
z[:, -1] = 5*x + 2

# Ax = b
size = (n-2) * (m-2)

A = np.empty((size, size))
np.fill_diagonal(A, -4)

b = np.zeros((n-2, m-2))

def flatten_index(i, j):
    i += (i < 0) * (n-2)
    j += (j < 0) * (m-2)
    return i * (m-2) + j

# corners
b[0, 0]   = - (z[0, 1]   + z[1, 0])
b[0, -1]  = - (z[0, -2]  + z[1, -1])

b[-1, 0]  = - (z[-1, 1]  + z[-2, 0])
b[-1, -1] = - (z[-1, -2] + z[-2, -1])

row = flatten_index(0, 0)
A[row, flatten_index(0, 1)] = 1
A[row, flatten_index(1, 0)] = 1

row = flatten_index(0, -1)
A[row, flatten_index(0, -2)] = 1
A[row, flatten_index(1, -1)] = 1

row = flatten_index(-1, 0)
A[row, flatten_index(-1, 1)] = 1
A[row, flatten_index(-2, 0)] = 1

row = flatten_index(-1, -1)
A[row, flatten_index(-1, -2)] = 1
A[row, flatten_index(-2, -1)] = 1


# b: first and last rows
b[0,  1:-1] = -z[0,  2:-2]
b[-1, 1:-1] = -z[-1, 2:-2]

# b: first and last columns
b[1:-1, 0] = -z[2:-2, 0]
b[1:-1, -1] = -z[2:-2, -1]

sz = b.shape[1]
# A: first row
for j in range(1, sz-1):
    row = flatten_index(0, j)
    A[row, row - 1] = 1
    A[row, row + 1] = 1
    A[row, row + sz] = 1

# A: last row
for j in range(1, sz-1):
    row = flatten_index(-1, j)
    A[row, row - 1] = 1
    A[row, row + 1] = 1
    A[row, row - sz] = 1

# A: first column
for i in range(1, sz-1):
    row = flatten_index(i, 0)
    A[row, row - sz] = 1
    A[row, row + sz] = 1
    A[row, row + 1] = 1

# A: last column
for i in range(1, sz-1):
    row = flatten_index(i, -1)
    A[row, row - sz] = 1
    A[row, row + sz] = 1
    A[row, row - 1] = 1


for i in range(2, sz-2):
    for j in range(2, sz-2):
        row = flatten_index(i, j)
        A[row, row + 1] = 1
        A[row, row - 1] = 1
        A[row, row + sz] = 1
        A[row, row - sz] = 1



b_ravel = b.ravel()
ans = np.linalg.solve(A, b_ravel)
ans = ans.reshape(b.shape)

z[1:-1, 1:-1] = ans


fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')


x, y = np.meshgrid(x, y)
ax.plot_surface(x, y, z.transpose(), color='b')

plt.show()
