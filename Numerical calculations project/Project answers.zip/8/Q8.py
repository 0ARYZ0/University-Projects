def our_function(iL1,iL2):
    es = 20
    R1 = 2000
    R2 = 5000
    R3 = 2000
    R4 = 3000
    R5 = 2000
    R = R5 + (1/(1/R3+1/R4))
    c1 = 50*10**(-6)
    c2 = 100*10**(-6)
    L1 = 50*10**(-6)
    L2 = 10*10**(-6)
    v_c1 = (7*iL1) / c1
    v_c2 = 7*(iL1+iL2) / c2
    

    our_function = (-iL1*(R1 + R))/L1 - (iL2*R)/L1 - (v_c1)/L1 - (v_c2)/L1 + R4/(L1*(R3+R4))
    return our_function



def euler(x0,y0,xn,n):
    
    h = (0.01)    
    i=0
    while i < n:
        slope = our_function(x0, y0)
        yn0 = y0 + h * slope
        yn = y0 + h/2 * ( slope + round(our_function(x0+h,yn0),3))

        print('%.4f\t%.4f\t%0.4f\t%.4f'% (round(x0,3),round(y0,3),round(slope,3),round(yn,3)))
        print('------------------------------')
        y0 = yn
        x0 = x0+h
        i=i+1
    
    print('\nIN x=%.4f, y=%.4f' %(round(xn,3),round(yn,3)))

x0=0
y0=0
xn = 1
step = 700
euler(x0,y0,xn,step)