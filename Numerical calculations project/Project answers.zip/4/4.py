from math import sin, cos

a, b = -7, 6.5

f = lambda x: sin(31*x) - 2*cos(23*x)

step = 0.01

x = a
root_ranges = []

while x < b:

    f_left = f(x)
    f_right = f(x + step)

    # f(x) has different sign than f(x + step)
    if (f_left > 0) != (f_right > 0):
        root_ranges.append(x)

    x += step

print(f'f has {len(root_ranges)} roots in these ranges:')
for x in root_ranges:
    print(f'[{x:.2f}, {x + step :.2f}]')
print()

def regula_falsi(f, a, b, n=10):

    for i in range(n):
        x_new = b - (b - a) / (f(b) - f(a)) * f(b)

        if (f(x_new) > 0) == (f(a) > 0):
            a, b = x_new, b

        else:
            a, b = a, x_new

    return x_new

for x in root_ranges:
    a, b = x, x + step

    root = regula_falsi(f, a, b)
    print(f'f({root}) = {f(root)}')

