def f_a(x):
    return x**3 + 4*x**2 -2

def bisection(min, max, approximation):
    step = 0
    x = 0
    while True:
        x = (max + min)/2
        fx = f_a(x)
        temp = fx * f_a(min)
        if(temp < 0):
            max = x
        elif(temp > 0):
            min = x
        else:
            break
        if(abs(fx) <= approximation):
            break
        step += 1
    return x, step

def f_b(x):
    return x**3 - (x**4 + x**2 + 5)**(1/3)

def fd_b(x):
    return 3*x**2 - ((4*x**3 + 2*x)/(3*(x**4 + x**2 + 5)**(2/3)))

def newton(x0, min, max, steps):
    x = x0
    for i in range(steps):
        fx = f_b(x)
        fx = round(fx, 4)
        fdx = fd_b(x)
        fdx = round(fdx, 4)
        x = x - (fx/fdx)
        x = round(x, 4)
    return round(x, 4)

def f_c(x):
    return x**3 - 2**(x**(0.5))

def regularFalsi(min, max, approximation):
    x = 0
    while True:
        fmax = f_c(max)
        fmax = round(fmax , 4)
        fmin = f_c(min)
        fmin = round(fmin, 4)
        x = max - ((max - min)/(fmax - fmin))*fmax
        x = round(x, 4)
        fx = f_c(x)
        fx = round(fx, 4)
        if(abs(fx) < approximation):
            break
        if(fx*fmin > 0):
            min = x
        else:
            max = x
    return x


x_a, steps = bisection(0, 1, 0.004)
x_b = newton(1, 0, 3, 15)
x_c = regularFalsi(1, 2, 0.001)

print("A: x = " + str(x_a) + "   steps = " + str(steps))
print("B: x = " + str(x_b))
print("C: x = " + str(x_c))
