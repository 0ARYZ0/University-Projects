# takes about 15 seconds
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

h = 0.01

a, b = 0, 10
c, d = 0, 8

# linspace takes half-open intervals
y = np.arange(c, d + h, h)
x = np.arange(a, b + h, h)

n = x.size
m = y.size

z = np.zeros((n, m))

# boundary conditions
z[0] = y
z[-1] = 3 * y

z[:, 0] = 6
z[:, -1] = 5*x + 2

# number of iterations
n_iter = 15

for _ in range(n_iter):
    new_z = z.copy()
    for i in range(1, z.shape[0]-1):
        for j in range(1, z.shape[1]-1):
            new_z[i, j] = (z[i - 1, j] +
                    z[i + 1, j] +
                    z[i, j - 1] +
                    z[i, j + 1]) / 4

    z = new_z

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

x, y = np.meshgrid(x, y)
ax.plot_wireframe(x, y, z.transpose(), color='b')

plt.show()
