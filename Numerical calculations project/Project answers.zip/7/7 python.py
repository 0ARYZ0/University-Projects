import matplotlib.pyplot as plt

with open("deta.txt") as file:
    lines = file.readlines()

def sep(line):
    x = ''
    y = ''
    i = 0
    while(line[i] != ' '):
        x += line[i]
        i += 1
    i += 1
    while(line[i] != '\n'):
        y += line[i]
        i += 1
        if i == len(line) -1:
            break
    return float(x), float(y)

def simpson(size):
    size -= 1
    res = 0
    start = xs[0]
    end = xs[size]
    res += ys[0] + ys[size]
    for i in range(1, size - 1):
        if(i%2 == 1):
            res += 4 * ys[i]
        else:
            res += 2 * ys[i]
    res *= (end - start)/(3 * size)
    return res

def centeral_difference(size):
    size -= 1
    dys = []
    for i in range(1, size):
        dys += [(ys[i + 1] - ys[i - 1]) / ( xs[i + 1] - xs[i - 1])]
    return dys

def sec_der(first, last):
    last -= 1
    dys = []
    for i in range(first, last):
        dys += [(ys[i + 1] - 2*ys[i] + ys[i - 1]) / (xs[i + 1] - xs[i])**2]
    return dys


xs = []
ys = []
for line in lines:
    x, y = sep(line)
    xs += [x]
    ys += [y]

integral = simpson(len(xs))
print("integral = " + str(integral))

derivative = centeral_difference(len(xs))

plt.plot(xs[1:-1], derivative)
plt.title("derivative diagram")
plt.show()

second_derivative = sec_der(5, 9991)
plt.plot(xs[5:-11], second_derivative)
plt.title("second derivative diagram")
plt.show()
