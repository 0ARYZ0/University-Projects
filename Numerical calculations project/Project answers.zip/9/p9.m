clc
clear
%\Problem 9 of the Project
%Group: Ahmadreza Yazdani , Mahdi Mardani , Mani Alimadadi

h = (8-2)/100;
x = 2:0.06:8;         % x space
y = zeros(2,length(x));    % Memory allocation
y=[1;1];  % initial condition

for i=1:(length(x)-1)                             
% i=1:(length(x)-1)                              
    k1(:,i) = ode1( x(i)         , y(:,i)            );
    k2(:,i) = ode1( x(i) + 0.5*h , y(:,i) + 0.5*h*k1(:,i) ); 
    k3(:,i) = ode1( x(i) + 0.5*h , y(:,i) + 0.5*h*k2(:,i) ); 
    k4(:,i) = ode1( x(i) +     h , y(:,i) +     h*k3(:,i) ); 
    y(2,i+1) = y(2,i) + (1/6)*( k1(2,i) + 2*k2(2,i) + 2*k3(2,i) + k4(2,i) )*h;  
    y(1,i+1) = y(1,i) + (1/6)*( k1(1,i) + 2*k2(1,i) + 2*k3(1,i) + k4(1,i) )*h;
end
figure, plot(x, y(1,:))  % plotting y
title("y")
figure, plot(x, y(2,:))  % plotting y'
title("y'")
answer = y(1,8);
fprintf('\n y(8) : %2.5f\n ', answer);



function yp = ode1(x,y)
  yp= [y(2);(x^2)*y(1)+(x^4)*log(x)-4*y(2)];
end