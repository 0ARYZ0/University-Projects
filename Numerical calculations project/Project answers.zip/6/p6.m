clc
clear
%\Problem 6 of the Project
%Group: Ahmadreza Yazdani , Mahdi Mardani , Mani Alimadadi
A = [9,-3,-6;2,8,2;-5,10,7];
u = [1;1;1];
epsilon = 0.01; %error of tolerance
m1=1;
v=A*u; 
m2=max(abs(v));
err=abs(m1-m2);
%Calculating the greatest eigenvalue.
 while err>epsilon  
   v=A*u; 
   m2=max(abs(v));
   if m2 == 0;
       fprintf('\n We have a Divide by zero! So we cannot calculate the value. %2.5f \n ')
       m1 = 0;
       break
   end
   u=v/m2;
   err=abs(m1-m2);
   m1=m2;
 end
fprintf('\n Possible greatest eigenvalue is %2.5f \n',m1);
pos1 = m1;


u = [1;1;1];
epsilon = 0.01;
m1=1;
v=A*u; 
m2=max(abs(v));
err=abs(m1-m2);
%Calculating the least eigenvalue.
 while err>epsilon  
   v=inv(A)*u; 
   m2=max(abs(v));
   if m2 == 0;
       fprintf('\n We have a Divide by zero! So we cannot calculate the value. %2.5f \n ')
       m1 = 0;
       break
   end
   u=v/m2;
   err=abs(m1-m2);
   m1=m2;
 end
fprintf('\n Possible least eigenvalue is %2.5f \n',1/m1);
pos_inv1 = 1/m1;

u = [1;1;1];
epsilon = 0.01;
m1=1;
v=A*u; 
m2=max(abs(v));
err=abs(m1-m2);
 while err>epsilon  
   v=A*u; 
   m2=min(abs(v));
   if m2 == 0;
       fprintf('\n We have a Divide by zero! So we cannot calculate the value. %2.5f \n ')
       m1 = 0;
       break
   end
   u=v/m2;
   err=abs(m1-m2);
   m1=m2;
 end
fprintf('\n Possible greatest eigenvalue is %2.5f \n',m1);
pos2 = m1;

u = [1;1;1];
epsilon = 0.01;
m1=1;
v=A*u; 
m2=max(abs(v));
err=abs(m1-m2);
 while err>epsilon  
   v=inv(A)*u; 
   m2=min(abs(v));
   if m2 == 0;
       fprintf('\n We have a Divide by zero! So we cannot calculate the value. %2.5f \n ')
       m1 = 0;
       break
   end
   u=v/m2;
   err=abs(m1-m2);
   m1=m2;
 end
fprintf('\n Possible least eigenvalue is %2.5f \n',1/m1);
pos_inv2 = 1/m1;
%choon nemidanim A manfi moaian ast ya mosbat moaian javab haye har 2 rah
%ro bayad moghayese konim
if pos1>pos2
    fprintf('\n FINAL: The greatest eigenvalue is %2.5f \n',pos1);
else 
    fprintf('\n FINAL: The greatest eigenvalue is %2.5f \n',pos2);
end

if pos_inv1<pos_inv2
    fprintf('\n FINAL: The least eigenvalue is %2.5f \n',pos_inv1);
else 
    fprintf('\n FINAL: The least eigenvalue is %2.5f \n',pos_inv2);
end
